﻿// See https://aka.ms/new-console-template for more information
using Final_POE_Part_1;

class Poe
{


    public static void Main()
    {

        addClass i = new addClass();    //Creates object instance of addClass  
        i.addRun();                     //Calls the method from addRun from addClass


    }






}
